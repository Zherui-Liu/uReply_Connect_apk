package com.example.ur_1;

import android.app.Activity;

import java.util.ArrayList;
import java.util.List;

public class ActivityCollector {
    //最初是为了实现两次退出而定义的类，我们这里用一个列表来管理我们的所有活动，并且用列表的add和remove来使得list和我们的实际保持一致，用活动的方法finish()来让活动退出
    public static List<Activity> activities = new ArrayList<>();

    public static void addActivity(Activity activity){
        activities.add(activity);
    }

    public static void removeActivity(Activity activity){
        activities.remove(activity);
    }

    public static void finishAll(){
        for (Activity activity:activities){
            if (!activity.isFinishing()){
                activity.finish();
            }
        }
    }
}

