package com.example.ur_1.Activity;

import android.app.ActivityOptions;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ur_1.R;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SignIn extends BaseActivity {//通常来说是第二个界面
    private EditText email;
    private EditText code;
    private SharedPreferences pref; //这个是用于管理数据库的变量
    private SharedPreferences.Editor editor; //用来存数据的对象

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        Intent intent = getIntent();
        String ISIN = intent.getStringExtra("extra_data");
        if (ISIN.equals("1")){
            Intent intent_1 = new Intent(SignIn.this,MyAccount.class);
            startActivity(intent_1);
        }
        //到达这里有两种情况，一种是自动登录失败，另一种情况是用户从setting中点了logout来到这里
        //我们在开启这个活动的时候尝试自动读取账号和密码
        //实例化我们需要的东西
        pref = getSharedPreferences("Login",0);
        email = (EditText)findViewById(R.id.signin_email);
        code = (EditText)findViewById(R.id.signin_code);
        Button signin_2 = (Button)findViewById(R.id.signin_2);
        //不论是登录失败还是logout，我们都保留用户原来的密码
        String emailstring = pref.getString("email","");
        String codestring = pref.getString("code","");
        email.setText(emailstring);
        code.setText(codestring);

        //这里设置一下框架下面的signup的颜色
        TextView signup = (TextView)findViewById(R.id.signup);
        signup.setTextColor(Color.rgb(0,255,125));
        signup.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);


        //获取账号和密码以及发送登录请求以及记住密码
        signin_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//              获取邮箱和密码
                String semail = email.getText().toString();
                String scode = code.getText().toString();
//                发送登录请求，以及，在跳转之前，如果登录成功的话，我们先保存账号和密码
                sendRequestWithHttpURLConnection(semail,scode);
            }
        });

    }



    public void sendRequestWithHttpURLConnection(final String semail, final String scode){
        //发起网络请求
        new Thread(new Runnable() {

            @Override
            public void run() {
                HttpURLConnection connection = null;
                BufferedReader reader = null;
                try {
                    URL url = new URL("http://ureplydev4.ureply.mobi/uconnect/json/login.php");
                    connection = (HttpURLConnection)url.openConnection();
                    connection.setRequestMethod("POST");
                    DataOutputStream outputStream = new DataOutputStream(connection.getOutputStream());
                    outputStream.writeBytes("action=GetList&userlogin="+semail+"&password="+scode);
                    connection.setConnectTimeout(8000);
                    connection.setReadTimeout(8000);
                    InputStream in = connection.getInputStream();
                    //读取数据流
                    reader = new BufferedReader(new InputStreamReader(in));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while((line = reader.readLine())!=null){
                        response.append(line);
                    }
                    showResponse(response.toString());
                }catch (Exception e){
                    e.printStackTrace();
                }
                if (connection!=null){
                    connection.disconnect();
                }
            }
        }).start();
    }

    private void showResponse(final String response){
        runOnUiThread(new Runnable() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void run() {
                Pattern pattern = Pattern.compile("states\":(.+?),");
                Matcher matcher = pattern.matcher(response);
                if(matcher.find()){
                    if (matcher.group(1).equals("1")){
                        //先保存密码
                        String emailstring = email.getText().toString();
                        String codestring = code.getText().toString();
                        editor = pref.edit();
                        editor.putString("email",emailstring);
                        editor.putString("code",codestring);
                        editor.apply();
                        //表示登录成功和界面跳转
                        Toast.makeText(SignIn.this,"Login Successfully",Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(SignIn.this,MyAccount.class);
//                        startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(SignIn.this).toBundle());
                        startActivity(intent);
                    }else{
                        Toast.makeText(SignIn.this,"Please enter the correct email and password",Toast.LENGTH_SHORT).show();
                        editor = pref.edit();
                        editor.clear();
                        editor.commit();
                    }
                }
            }
        });
    }
}
