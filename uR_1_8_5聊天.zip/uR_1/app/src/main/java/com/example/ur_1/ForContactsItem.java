package com.example.ur_1;

public class ForContactsItem {
    //定义Contactslist中的每一个Item
    private String truename;
    private String firstname;
    private String lastname;
    private int imgid;
    private String email;
    private String phone;
    private String school;
    private String state; //like student or teacher

    public ForContactsItem(String truename,String firstname,String lastname,int imgid,String email,String phone,String school,String state){
        this.truename = truename;
        this.firstname = firstname;
        this.lastname = lastname;
        this.imgid = imgid;
        this.email = email;
        this.phone = phone;
        this.school = school;
        this.state = state;
    }

    public String getTruename() {
        return truename;
    }

    public String getFirstname(){
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public int getImgid(){
        return imgid;
    }

    public String getEmail(){ return email; }

    public String getPhone() {
        return phone;
    }

    public String getSchool() {
        return school;
    }

    public String getState() {
        return state;
    }
}
