package com.example.ur_1.Activity;

import android.annotation.TargetApi;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.transition.Explode;
import android.transition.Slide;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.widget.Toast;

import com.example.ur_1.ActivityCollector;
import Fragment.FragmentAccount;
import Fragment.FragmentContacts;
import Fragment.FragmentNotification;
import Fragment.FragmentPrivatechat;
import Fragment.FragmentRegulargroups;
import Fragment.FragmentSetting;
import com.example.ur_1.R;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MyAccount extends BaseActivity {

    private DrawerLayout mDrawerlayout;
    private Fragment isfragment; //用来存储当前的fragment
    //实例用于跳转的Fragment
    final FragmentContacts mfragmentContacts = new FragmentContacts();
    final FragmentAccount mfragmentAccount = new FragmentAccount();
    final FragmentNotification mfragmentNotification = new FragmentNotification();
    final FragmentRegulargroups mfragmentRegulargroups = new FragmentRegulargroups();
    final FragmentPrivatechat mfragmentPrivatechat = new FragmentPrivatechat();
    final FragmentSetting mfragmentSetting = new FragmentSetting();
    private SharedPreferences pref_0; //for contacts list
    private SharedPreferences.Editor editor_0;
    private String SelectMenu = "myaccount";

    //让我们自定义的Toolbar可以被看见
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.toolbar,menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        switch (SelectMenu){
            case "myaccount":
                menu.findItem(R.id.add_tool).setVisible(false);
                menu.findItem(R.id.person_tool).setVisible(false);
                menu.findItem(R.id.group_tool).setVisible(false);
                menu.findItem(R.id.setting_tool).setVisible(false);
                break;
            case "contacts":
                menu.findItem(R.id.person_tool).setVisible(false);
                menu.findItem(R.id.group_tool).setVisible(false);
                menu.findItem(R.id.setting_tool).setVisible(false);
                break;
            case "Notification":
                menu.findItem(R.id.add_tool).setVisible(false);
                menu.findItem(R.id.person_tool).setVisible(false);
                menu.findItem(R.id.group_tool).setVisible(false);
                menu.findItem(R.id.setting_tool).setVisible(false);
                break;
            case "regulargroups":
                menu.findItem(R.id.add_tool).setVisible(false);
                menu.findItem(R.id.person_tool).setVisible(false);
                menu.findItem(R.id.group_tool).setVisible(false);
                menu.findItem(R.id.setting_tool).setVisible(false);
            case "privatechats":
                menu.findItem(R.id.add_tool).setVisible(false);
                menu.findItem(R.id.person_tool).setVisible(false);
                menu.findItem(R.id.group_tool).setVisible(false);
                menu.findItem(R.id.setting_tool).setVisible(false);
            case "setting":
                menu.findItem(R.id.add_tool).setVisible(false);
                menu.findItem(R.id.person_tool).setVisible(false);
                menu.findItem(R.id.group_tool).setVisible(false);
                menu.findItem(R.id.setting_tool).setVisible(false);
        }
        return true;
    }

    //准备：设置菜单功能，当点击Home的时候，打开侧栏
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                mDrawerlayout.openDrawer(GravityCompat.START);
                break;
            default:
        }
        return true;
    }



    //For Post message to server
    private String gurl = "http://ureplydev4.ureply.mobi/uconnect/json/login.php";
    private String spost = "action=GetList&userlogin="+"zherui"+"&password="+"demo";


    //这里才开始设置onCreate
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setEnterTransition(new Slide().setDuration(2000));
        getWindow().setExitTransition(new Slide().setDuration(2000));
        setContentView(R.layout.activity_my_account);

        //CONTACTSLIST
        //1. get data locally
        pref_0 = getSharedPreferences("Login",0);//NOTE!!! Don't need add this in front.That will make it unreadable
        String emailstring = pref_0.getString("email","");




        //2. Loading contact data from the server
        gurl = "http://ureplydev4.ureply.mobi/uconnect/json/contact_list.php";
        spost = "action=GetList&username="+emailstring+"&client=student&sortfield=name&orderfield=";
        sendRequestWithHttpURLConnection(gurl,spost,"ContactList");//3. Save it by SharedPreference
        spost = "action=GetList&username="+emailstring+"&client=teacher&sortfield=name&orderfield=";
        sendRequestWithHttpURLConnection(gurl,spost,"ContactList_t");//3. Save it by SharedPreference
        spost = "action=GetList&username="+emailstring+"&client=administrator&sortfield=name&orderfield=";
        sendRequestWithHttpURLConnection(gurl,spost,"ContactList_a");//3. Save it by SharedPreference
        //4. get the chatlist
        gurl = "http://ureplydev4.ureply.mobi/uconnect/json/private_chatlist.php";
        spost = "username=zherui";
        sendRequestWithHttpURLConnection_chatlist(gurl,spost,"chatlist");


        //添加默认Fragment：MyAccount
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        FragmentAccount fragmentAccount = new FragmentAccount();
        fragmentTransaction.add(R.id.fragment_container,fragmentAccount);
        fragmentTransaction.commit();
        isfragment = fragmentAccount;




        //设置ToolBar的样子
        Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionbar = getSupportActionBar();
        actionbar.setTitle("My Account");
        if (actionbar != null){
            actionbar.setDisplayHomeAsUpEnabled(true);
            actionbar.setHomeAsUpIndicator(R.drawable.sidebar);
        }

//        设置Drawerlayout中的点击实例
        mDrawerlayout = (DrawerLayout)findViewById(R.id.drawer_layout);
        NavigationView navView = (NavigationView) findViewById(R.id.nav_view);
        navView.setCheckedItem(R.id.nav_account);
        navView.setItemIconTintList(null);

        //跳转准备
        navView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                //跳转
                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
                setSupportActionBar(toolbar);
                ActionBar actionbar = getSupportActionBar();

                switch(item.getItemId()){
                    case R.id.nav_contacts:
//                        Toast.makeText(MyAccount.this,"Let's go to Contacts",Toast.LENGTH_SHORT).show();
                        SwichFragment(isfragment,mfragmentContacts);
                        //设置跳转后的Toolbar
                        if (actionbar != null){
                            actionbar.setTitle("Contacts");
                        }
                        mDrawerlayout.closeDrawers();
                        SelectMenu = "contacts";
                        break;
                    case R.id.nav_account:
//                        Toast.makeText(MyAccount.this,"Let's go to Myaccount",Toast.LENGTH_SHORT).show();
                        SwichFragment(isfragment,mfragmentAccount);
                        //设置跳转后的Toolbar
                        actionbar.setTitle("My Account");
                        mDrawerlayout.closeDrawers();
                        SelectMenu = "myaccount";
                        break;
                    case R.id.nav_notification:
//                        Toast.makeText(MyAccount.this,"Notificationn!",Toast.LENGTH_SHORT).show();
                        SwichFragment(isfragment,mfragmentNotification);
                        actionbar.setTitle("Notification");
                        mDrawerlayout.closeDrawers();
                        SelectMenu="Notification";
                        break;
                    case R.id.nav_regulargroups:
//                        Toast.makeText(MyAccount.this,"Groups!!!",Toast.LENGTH_SHORT).show();
                        SwichFragment(isfragment,mfragmentRegulargroups);
                        actionbar.setTitle("Regular Groups");
                        mDrawerlayout.closeDrawers();
                        SelectMenu = "regulargroups";
                        break;
                    case R.id.nav_privatechat:
//                        Toast.makeText(MyAccount.this,"Private Chat~",Toast.LENGTH_SHORT).show();
                        SwichFragment(isfragment,mfragmentPrivatechat);
                        actionbar.setTitle("Private Chats");
                        mDrawerlayout.closeDrawers();
                        SelectMenu="privatechats";
                        break;
                    case R.id.nav_settings:
//                        Toast.makeText(MyAccount.this,"Setting",Toast.LENGTH_SHORT).show();
                        SwichFragment(isfragment,mfragmentSetting);
                        actionbar.setTitle("Setting");
                        mDrawerlayout.closeDrawers();
                        SelectMenu="setting";
                        break;
                }
                return true;
            }
        });
    }

    public void sendRequestWithHttpURLConnection_chatlist(final String gurl, final String spost, final String Filename){
        //发起网络请求
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection connection = null;
                BufferedReader reader = null;
                try {
                    URL url = new URL(gurl);
                    connection = (HttpURLConnection)url.openConnection();
                    connection.setRequestMethod("POST");
                    DataOutputStream outputStream = new DataOutputStream(connection.getOutputStream());
                    outputStream.writeBytes(spost);
                    connection.setConnectTimeout(8000);
                    connection.setReadTimeout(8000);
                    InputStream in = connection.getInputStream();
                    //读取数据流
                    reader = new BufferedReader(new InputStreamReader(in));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while((line = reader.readLine())!=null){
                        response.append(line);
                    }
                    showResponse_chatlist(response.toString(),Filename);
                }catch (Exception e){
                    e.printStackTrace();
                }
                if (connection!=null){
                    connection.disconnect();
                }
            }
        }).start();
    }

    private void showResponse_chatlist(final String response,final String Filename){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                editor_0 = pref_0.edit();
                editor_0.putString(Filename,response);
                editor_0.apply();
                Log.d("debug_ma_chatlist",response);

                //Match and add to SharedPreference
                Pattern pattern0 = Pattern.compile("\"sessionid\":\"(.+?)\"");
                Matcher matcher0 = pattern0.matcher(response);
                Pattern pattern1 = Pattern.compile("\"receiver\":\"(.+?)\"");
                Matcher matcher1 = pattern1.matcher(response);
                while (matcher0.find() && matcher1.find()){
                    editor_0.putString("chatlist_"+matcher1.group(1),matcher0.group(1));
                    editor_0.apply();
                    Log.d("chatlist_"+matcher1.group(1),matcher0.group(1));
                }

            }
        });
    }


    public void sendRequestWithHttpURLConnection(final String gurl, final String spost, final String Filename){
        //发起网络请求
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection connection = null;
                BufferedReader reader = null;
                try {
                    URL url = new URL(gurl);
                    connection = (HttpURLConnection)url.openConnection();
                    connection.setRequestMethod("POST");
                    DataOutputStream outputStream = new DataOutputStream(connection.getOutputStream());
                    outputStream.writeBytes(spost);
                    connection.setConnectTimeout(8000);
                    connection.setReadTimeout(8000);
                    InputStream in = connection.getInputStream();
                    //读取数据流
                    reader = new BufferedReader(new InputStreamReader(in));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while((line = reader.readLine())!=null){
                        response.append(line);
                    }
                    showResponse(response.toString(),Filename);
                }catch (Exception e){
                    e.printStackTrace();
                }
                if (connection!=null){
                    connection.disconnect();
                }
            }
        }).start();
    }

    private void showResponse(final String response,final String Filename){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                    editor_0 = pref_0.edit();
                    editor_0.putString(Filename,response);
                    editor_0.apply();
                    Log.d("debug_ma_e",response);
            }
        });
    }

    //模块化跳转操作
    public void SwichFragment(Fragment from, Fragment to){
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        if(from != to){
            fragmentTransaction.replace(R.id.fragment_container,to);
            fragmentTransaction.commit();
            isfragment = to;
        }
    }

    //下面按两次返回退出的功能的实现，因为到这里我们希望按两次退出之后不能够在回到Sign In的界面了。
    public boolean onKeyDown(int keyCode, KeyEvent event){
        if(keyCode==KeyEvent.KEYCODE_BACK){
            exit();
            return true;
        }
        return super.onKeyDown(keyCode,event);
    }

    private long time = 0;

    private void exit(){
        if(System.currentTimeMillis()-time>2000){
            time = System.currentTimeMillis();
            Toast.makeText(MyAccount.this,"Press BACK again to exit",Toast.LENGTH_SHORT).show();
        }else {
            ActivityCollector.finishAll();
        }
    }
}