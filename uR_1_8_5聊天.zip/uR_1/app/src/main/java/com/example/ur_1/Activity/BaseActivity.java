package com.example.ur_1.Activity;

import android.support.v7.app.AppCompatActivity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.example.ur_1.ActivityCollector;


public class BaseActivity extends AppCompatActivity {
//为了实现点两次返回而定义的类，所有你想要两次Back关闭的界面，都需要直接继承Basement而不是AppcompatActivity

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityCollector.addActivity(this);
    }
    @Override
    protected void onDestroy(){
        super.onDestroy();
        ActivityCollector.removeActivity(this);
    }
}
