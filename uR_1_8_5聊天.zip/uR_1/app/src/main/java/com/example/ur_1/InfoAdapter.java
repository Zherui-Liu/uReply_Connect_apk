package com.example.ur_1;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.TextView;

import java.util.List;

/**
 * Created by Administrator on 2018/7/17.
 */

public class InfoAdapter extends ArrayAdapter<InfoArticle> {

    private int resourceId;

    public InfoAdapter(Context context,int textViewResourceId, List<InfoArticle> objects){
        super(context,textViewResourceId, objects);
        resourceId = textViewResourceId;//对list中item起作用的Layout
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        InfoArticle infoarticle = getItem(position);
        View view = LayoutInflater.from(getContext()).inflate(resourceId,parent,false);
        //get到list中的名字
        TextView articlename = (TextView)view.findViewById(R.id.article_name);
        //get到每一项的内容
        EditText articlecontent = (EditText)view.findViewById(R.id.article_content);
        //设置名字
        articlename.setText(infoarticle.getName());
        //设置内容
        //对内容的引号进行修改~
        String content = infoarticle.getContent();
        String subcontent = content.substring(1,content.length()-1);
        articlecontent.setText(subcontent);
        return view;
    }
}
