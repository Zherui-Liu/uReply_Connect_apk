package com.example.ur_1.Activity;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;

import com.example.ur_1.Msg;
import com.example.ur_1.MsgAdapter;
import com.example.ur_1.R;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MsgActivity extends AppCompatActivity {

    private List<Msg> msgList = new ArrayList<>();
    List<Msg>real_msgList = new ArrayList<>(); //the msglist that display

    private EditText inputText;
    private Button send;
    private RecyclerView msgRecyclerView;
    private MsgAdapter adapter;

    private SharedPreferences pref0; //get my username
    private SharedPreferences pref_detail;//prepare get data from sharedprefercence
    private SharedPreferences.Editor editor_detail_msg;
    private String gurl;   //用于获取全部信息
    private String last_gurl; //用于获取最新的信息
    private String post;
    private String last_post;
    private String username;
    private String myemail;

    private int finish = 0;

    private Timer timer = new Timer();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_msg);

        real_msgList = new ArrayList<>();
        real_msgList.clear();//make sure real_msgList is empty

        initMsgs(); //init Messages,as a simplified version before facing reality

    }

    public void getlastMsgs(){
//        Log.d("initreal_Msg_length:",String.valueOf(real_msgList.size()));
        pref_detail = getSharedPreferences("Detail",0);
        //we will get chatting data here

        username = pref_detail.getString("truename","");
        Log.d("Msg_is",username);
        pref0 = getSharedPreferences("Login",0);
        myemail = pref0.getString("email","");

        last_gurl = "http://ureplydev4.ureply.mobi/uconnect/json/get_private_chatlist_lastmsg.php";
        last_post = "action=GetList&username="+myemail;

        last_sendRequestWithHttpURLConnection(last_gurl, last_post, "Msg_last_time"); //save the history in this way
    }

    private void initMsgs(){
//        Log.d("initreal_Msg_length:",String.valueOf(real_msgList.size()));
        pref_detail = getSharedPreferences("Detail",0);
        //we will get chatting data here

        username = pref_detail.getString("truename","");
        Log.d("Msg_is",username);
        pref0 = getSharedPreferences("Login",0);
        myemail = pref0.getString("email","");

        gurl = "http://ureplydev4.ureply.mobi/uconnect/json/private_chatrecord.php";
        post = "username="+myemail+"&receiver="+username;
        sendRequestWithHttpURLConnection(gurl, post, "Msg_"); //save the history in this way
    }

    //getting last message
    public void last_sendRequestWithHttpURLConnection(final String gurl, final String spost, final String Filename){
        finish = 1; //在这里就可以直接完成

        //发起网络请求
        new Thread(new Runnable() {

            @Override
            public void run() {

                HttpURLConnection connection = null;
                BufferedReader reader = null;
                try {
                    URL url = new URL(gurl);
                    connection = (HttpURLConnection)url.openConnection();
                    connection.setRequestMethod("POST");
                    DataOutputStream outputStream = new DataOutputStream(connection.getOutputStream());
                    outputStream.writeBytes(spost);
                    connection.setConnectTimeout(8000);
                    connection.setReadTimeout(8000);
                    InputStream in = connection.getInputStream();
                    //读取数据流
                    reader = new BufferedReader(new InputStreamReader(in));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while((line = reader.readLine())!=null){
                        response.append(line);
                    }
                    last_showResponse(response.toString(),Filename);

                }catch (Exception e){
                    e.printStackTrace();
                }
                if (connection!=null){
                    connection.disconnect();
                }
            }
        }).start();
    }
    private void last_showResponse(final String response,final String Filename){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Log.d("initreal_Msg_length2:",String.valueOf(real_msgList.size()));
                finish = 1;
                Log.d("debug_con_last",response);
                //获得之前最新的时间
                String previous_response = pref_detail.getString(Filename,"");
                Log.d("debug_con_last_1",previous_response);
                //获得目前最新的时间
                Pattern pattern0 = Pattern.compile("senttime\":\"(.+?)\",\"file");//message
                Matcher matcher0 = pattern0.matcher(response);

                //判断之后决定
                if (matcher0.find()){
                    Log.d("debug_con_last_2",matcher0.group(1));
                    //判断
                    if (!matcher0.group(1).equals(previous_response)){
                        Log.d("debug_con_last_equal","1");
                        //如果不相等的话就做下面，...如果相等就什么都不做
                        initMsgs();//全部更新一次
                        //存最新的数据(这些数据是要在下次进入的时候才会被实际执行的~)
                        editor_detail_msg = pref_detail.edit();
                        editor_detail_msg.putString(Filename,matcher0.group(1));
                        editor_detail_msg.apply();
                    }
                }
                Log.d("initreal_Msg_length2:",String.valueOf(real_msgList.size()));
            }
        });
    }

    //get all message and add them to list
    public void sendRequestWithHttpURLConnection(final String gurl, final String spost, final String Filename){
        finish = 1; //在这里就可以直接完成
        //发起网络请求
        new Thread(new Runnable() {

            @Override
            public void run() {

                HttpURLConnection connection = null;
                BufferedReader reader = null;
                try {
                    URL url = new URL(gurl);
                    connection = (HttpURLConnection)url.openConnection();
                    connection.setRequestMethod("POST");
                    DataOutputStream outputStream = new DataOutputStream(connection.getOutputStream());
                    outputStream.writeBytes(spost);
                    connection.setConnectTimeout(8000);
                    connection.setReadTimeout(8000);
                    InputStream in = connection.getInputStream();
                    //读取数据流
                    reader = new BufferedReader(new InputStreamReader(in));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while((line = reader.readLine())!=null){
                        response.append(line);
                    }
                    showResponse(response.toString(),Filename);

                }catch (Exception e){
                    e.printStackTrace();
                }
                if (connection!=null){
                    connection.disconnect();
                }
            }
        }).start();
    }

    private void showResponse(final String response,final String Filename){
        Log.d("initreal_Msg_length1:",String.valueOf(real_msgList.size()));
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Log.d("debug_con_d",response);
                editor_detail_msg = pref_detail.edit();
                editor_detail_msg.putString(Filename,response);
                editor_detail_msg.apply();
                finish = 1;

                //We match message first
                String msg = pref_detail.getString("Msg_","");
                Pattern pattern0 = Pattern.compile("message\":\"(.+?)\",\"senttime");//message
                Matcher matcher0 = pattern0.matcher(msg);
                Pattern pattern1 = Pattern.compile("username\":\"(.+?)\",\"autoid");//get the sender of messages
                Matcher matcher1 = pattern1.matcher(msg);

                while (matcher0.find()){
                    if (matcher1.find()) {
                        if (matcher1.group(1).equals(username)){ //means this message was she send to me.
                            Msg msg1 = new Msg(matcher0.group(1),Msg.TYPE_RECEIVED);
                            Log.d("matcher_msg1", matcher0.group(1));
                            msgList.add(msg1);

                        }else{
                            Msg msg2 = new Msg(matcher0.group(1),Msg.TYPE_SENT);
                            Log.d("matcher_msg2", matcher0.group(1));
                            msgList.add(msg2);
                        }
                    }
                    Log.d("msglen",String.valueOf(msgList.size()));
                }

                inputText = (EditText)findViewById(R.id.input_text);
                send = (Button)findViewById(R.id.send);

//                adapter.notifyItemInserted(msgList.size()-1);//刷新ListVeiw的显示

//                msgRecyclerView.scrollToPosition(msgList.size()-1);//定位到最后一行

                msgRecyclerView = (RecyclerView)findViewById(R.id.msg_recycler_view);
                LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
                msgRecyclerView.setLayoutManager(layoutManager);

                //将msgList非对象赋值给Msg
                //1. 获取长度
                int real_len = real_msgList.size();
                int msg_len = msgList.size();
                int i =0;
                for (Msg x :msgList
                     ) {
                    if (i>=real_len){
                        real_msgList.add(x);
                    }
                    i++;
                }

                Log.d("real_Msg_length:",String.valueOf(real_msgList.size()));
                Log.d("Msg_length:",String.valueOf(msgList.size()));

                adapter = new MsgAdapter(real_msgList);

                msgRecyclerView.setAdapter(adapter);

                msgRecyclerView.scrollToPosition(real_msgList.size()-1);//定位到最后一行

                msgList.clear();

                send.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        //get receiver's sessionid
                        String content = inputText.getText().toString();

                        String session = pref0.getString("chatlist_"+username,"");
                        Log.d("chatlist_2"+username,session);

//                        if (!session.equals("")){
                            final String add_msg_url = "http://ureplydev4.ureply.mobi/uconnect/json/add_private_msg.php";
                            final String add_msg_post = "username="+myemail+"&receiver="+username+"&message="+content+"&sessionid="+session;
                            Log.d("MasActivity_username",username);
                            if (!"".equals(content)){
                                Msg msg = new Msg(content,Msg.TYPE_SENT);
                                //begin to add this msg to Sever
                                new Thread(new Runnable() {
                                    @Override
                                    public void run() {
                                        HttpURLConnection connection = null;
                                        BufferedReader reader = null;
                                        try {
                                            URL url = new URL(add_msg_url);
                                            connection = (HttpURLConnection)url.openConnection();
                                            connection.setRequestMethod("POST");
                                            DataOutputStream outputStream = new DataOutputStream(connection.getOutputStream());
                                            outputStream.writeBytes(add_msg_post);
                                            connection.setConnectTimeout(8000);
                                            connection.setReadTimeout(8000);
                                            InputStream in = connection.getInputStream();
                                            //读取数据流
                                            reader = new BufferedReader(new InputStreamReader(in));
                                            StringBuilder response = new StringBuilder();
                                            String line;
                                            while((line = reader.readLine())!=null){
                                                response.append(line);
                                            }
//                                        showResponse(response.toString(),Filename);

                                        }catch (Exception e){
                                            e.printStackTrace();
                                        }
                                        if (connection!=null){
                                            connection.disconnect();
                                        }
                                    }
                                }).start();
//                            }



//                            msgList.add(msg);
//                            adapter.notifyItemInserted(msgList.size()-1);//刷新ListVeiw的显示
//                            msgRecyclerView.scrollToPosition(msgList.size()-1);//定位到最后一行
                            inputText.setText("");//clear our inputText
                        }
                    }
                });
                Log.d("initreal_Msg_length1:",String.valueOf(real_msgList.size()));
                //界面初始设置完毕，开始进行不断更新
                 //get the last messages
                //Try a timed loop

                timer.scheduleAtFixedRate(new TimerTask() {
                    @Override
                    public void run() {
                        getlastMsgs(); //init Messages,as a simplified version before facing reality
                    }
                },0,2000);

            }
        });
    }

    @Override
    protected void onDestroy() {
        timer.cancel();
        super.onDestroy();

    }
}
