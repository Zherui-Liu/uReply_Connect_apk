package com.example.ur_1;

import android.content.Intent;
import android.support.design.widget.TabLayout;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class POST  {
    private String url;
    private String spost; //what you post
    private String fmresponse;
    private String mresponse;

    public POST(String url,String spost){
        this.url=url;
        this.spost=spost;
        sendRequestWithHttpURLConnection(url,spost); //mresponse will be define in here
    }

    public String getMresponse() {
        sendRequestWithHttpURLConnection(url,spost);
        Log.d("debug-here-p-4",this.mresponse);
        return this.mresponse;
    }

    private void sendRequestWithHttpURLConnection(final String gurl, final String spost) {
        //发起网络请求


        new Thread(new Runnable(){
            @Override
            public void run() {
                HttpURLConnection connection = null;
                BufferedReader reader = null;
                try {
                    URL url = new URL(gurl);
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("POST");
                    DataOutputStream outputStream = new DataOutputStream(connection.getOutputStream());
                    outputStream.writeBytes(spost);
                    connection.setConnectTimeout(8000);
                    connection.setReadTimeout(8000);
                    InputStream in = connection.getInputStream();
                    //读取数据流
                    reader = new BufferedReader(new InputStreamReader(in));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    fmresponse = response.toString();
                    sresponse(fmresponse);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (connection != null) {
                    connection.disconnect();
                }
            }
        }).start();
    }

    private void sresponse(String fmresponse){
        this.mresponse = fmresponse;
        Log.d("debug-here-p-3",this.mresponse);
    }

}
