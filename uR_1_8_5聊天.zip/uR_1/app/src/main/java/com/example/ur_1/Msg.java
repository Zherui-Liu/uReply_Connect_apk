package com.example.ur_1;

public class Msg {

    public static final int TYPE_RECEIVED = 0;
    public static final int TYPE_SENT = 1;
    private String content;
    private int type;

    public Msg(String content,int type){
        this.content = content; //the content of the message
        this.type = type; //a message to be sent or to be received
    }

    public String getContent() {
        return content;
    }

    public int getType() {
        return type;
    }
}
