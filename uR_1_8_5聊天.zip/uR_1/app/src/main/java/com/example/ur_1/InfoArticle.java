package com.example.ur_1;

import android.util.Log;

/**
 * Created by Administrator on 2018/7/17.
 */

//用于存储MyAccount中
public class InfoArticle {
    private String name;
    private String content;

    public InfoArticle(String name,String content){
        this.name = name;
        this.content = content;
}

    public String getName()
    {
        return name;
    }

    public  String getContent() {
        return content;
    }
}
