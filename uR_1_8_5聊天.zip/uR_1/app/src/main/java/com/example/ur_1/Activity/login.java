package com.example.ur_1.Activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ur_1.R;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class login extends BaseActivity {
    private SharedPreferences pref;
    private SharedPreferences.Editor editor;
    public String ISIN = "0";
    private SharedPreferences pref_MyAccount;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        pref_MyAccount = getSharedPreferences("myaccount",0);
        //我们居然在这里创建了一个signIn的实例？！！！
        SignIn signIn = new SignIn();

        //首先我们先看看本地有无已经保存到的密码
        pref = getSharedPreferences("Login",0);
        try{
            String emailstring = pref.getString("email","");
            String codestring = pref.getString("code","");
            sendRequestWithHttpURLConnection(emailstring,codestring);
        }catch (Exception e){
            e.printStackTrace();
        }


        final TextView signup = (TextView)findViewById(R.id.signup);
        signup.setTextColor(Color.rgb(0,255,125));
        signup.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
        Button signin = (Button)findViewById(R.id.signin);
        signin.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(login.this,SignIn.class);
                intent.putExtra("extra_data",ISIN);//将这个证据传递给下一个活动
                startActivity(intent);
            }
        });
    }


    private void sendRequestWithHttpURLConnection(final String semail, final String scode) {
        //发起网络请求
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection connection = null;
                BufferedReader reader = null;
                try {
                    URL url = new URL("http://ureplydev4.ureply.mobi/uconnect/json/login.php");
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("POST");
                    DataOutputStream outputStream = new DataOutputStream(connection.getOutputStream());
                    outputStream.writeBytes("action=GetList&userlogin=" + semail + "&password=" + scode);
                    connection.setConnectTimeout(8000);
                    connection.setReadTimeout(8000);
                    InputStream in = connection.getInputStream();
                    //读取数据流
                    reader = new BufferedReader(new InputStreamReader(in));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    showResponse(response.toString());
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (connection != null) {
                    connection.disconnect();
                }
            }
        }).start();
    }

    private void showResponse(final String response){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
//                Pattern pattern = Pattern.compile("states\":(.+?),");
                Pattern pattern = Pattern.compile("[a-z]\":(.*?),\"");
                Matcher matcher = pattern.matcher(response);

                List<String> list = new ArrayList<>();
                Integer integer = 0;
                while (matcher.find()){
                    list.add(matcher.group(1));
                    Log.d("Debug here"+integer.toString(),list.get(integer));
                    integer = integer+1;
                }

                if (list.get(0).equals("1")){
                        //表示登录成功和界面跳转
                        Toast.makeText(login.this,"Login Successfully",Toast.LENGTH_SHORT).show();
                        ISIN = "1";//登陆成功的证明
                        Intent intent = new Intent(login.this,SignIn.class);
                        intent.putExtra("extra_data",ISIN);//将这个证据传递给下一个活动
//对数据的处理，可以用Intent来进行传输
//                        intent.putExtra("extra_firstname",list.get(3));
//                        intent.putExtra("extra_lastname",list.get(4));
//                        intent.putExtra("extra_email",list.get(5));
//                        intent.putExtra("extra_tele",list.get(7));
//                        intent.putExtra("extra_faculty",list.get(8));
//但是我们也可以用pref来存在本地
                        editor = pref_MyAccount.edit();
                        editor.putString("ma_firstname",list.get(3));
                        editor.putString("ma_lastname",list.get(4));
                        editor.putString("ma_email",list.get(5));
                        editor.putString("ma_tele",list.get(7));
                        editor.putString("ma_faculty",list.get(8));
                        editor.apply(); //
                    Log.d("Debug-here-login","3");
                        startActivity(intent);
                    }else{
                        //自动登录错误，用户可能已经修改了email或者密码，但是我们这时可以选择不清除原来的账号和密码记录
                        Toast.makeText(login.this,"Please enter your email and password to login",Toast.LENGTH_SHORT).show();
                    }
            }
        });
    }
}
