package com.example.ur_1;

import android.content.Context;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class ForConAdapter extends ArrayAdapter {
    private int resourceId;

    public ForConAdapter(Context context, int textViewResourceId, List<ForContactsItem> objects){
        super(context,textViewResourceId, objects);
        resourceId = textViewResourceId;//对list中item起作用的Layout
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        ForContactsItem forContactsItem = (ForContactsItem) getItem(position);
        View view = LayoutInflater.from(getContext()).inflate(resourceId,parent,false);
        //get到list中的名字
        TextView articlename = (TextView)view.findViewById(R.id.contacts_name);
        //头像的layout
        ImageView imageView = (ImageView)view.findViewById(R.id.contacts_img);
        //设置名字
        articlename.setText(forContactsItem.getFirstname()+" "+forContactsItem.getLastname());
        //设置图像
        imageView.setBackgroundResource(forContactsItem.getImgid());
        return view;
    }

}
