package com.example.ur_1.Activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.app.SharedElementCallback;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.transition.Slide;
import android.transition.Transition;
import android.transition.TransitionInflater;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import com.example.ur_1.R;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import Fragment.FragmentAccount;
import Fragment.FragmentContacts_detail;
import Fragment.FragmentSetting;

public class Contacts_detail extends AppCompatActivity {

    private SharedPreferences pref_detail; //get data
    private SharedPreferences.Editor editor_detail_msg; //save msg data
    private SharedPreferences pref0; //get my username
    private String gurl;
    private String post;

    private int finish = 0;//to check if we've got the data

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);;
        setContentView(R.layout.activity_contacts_detail);
        //Load Fragment Dynamically
        getFragmentManager().beginTransaction().replace(R.id.settingContainer,
                new FragmentContacts_detail()).commit();
        //Set the name
        pref_detail = getSharedPreferences("Detail",0);
        final String firstname = pref_detail.getString("firstname","");
        String lasttname = pref_detail.getString("lastname","");
        final String truename = pref_detail.getString("truename","");

        //Find the id of Layout of name
        TextView nameText = findViewById(R.id.contact_name);
        nameText.setText(firstname+" "+lasttname);
        Log.d("Contact_detail_truename",truename);

        //prepare to get history of chatting
            //1. get my username
        pref0 = getSharedPreferences("Login",0);
        String myemail = pref0.getString("email","");

            //2. API
        gurl = "http://ureplydev4.ureply.mobi/uconnect/json/private_chatrecord.php";
        post = "username="+myemail+"&receiver="+truename;

        //Let's go chatting from here
        Button button = findViewById(R.id.contact_message);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //send and get response
//                sendRequestWithHttpURLConnection(gurl, post, "Msg_"); //save the history in this way
                Intent intent = new Intent(Contacts_detail.this,MsgActivity.class);
                startActivity(intent);
            }
        });
    }

    public void sendRequestWithHttpURLConnection(final String gurl, final String spost, final String Filename){
        finish = 1; //在这里就可以直接完成
        //发起网络请求
        new Thread(new Runnable() {

            @Override
            public void run() {
                HttpURLConnection connection = null;
                BufferedReader reader = null;
                try {
                    URL url = new URL(gurl);
                    connection = (HttpURLConnection)url.openConnection();
                    connection.setRequestMethod("POST");
                    DataOutputStream outputStream = new DataOutputStream(connection.getOutputStream());
                    outputStream.writeBytes(spost);
                    connection.setConnectTimeout(8000);
                    connection.setReadTimeout(8000);
                    InputStream in = connection.getInputStream();
                    //读取数据流
                    reader = new BufferedReader(new InputStreamReader(in));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while((line = reader.readLine())!=null){
                        response.append(line);
                    }
                    showResponse(response.toString(),Filename);

                }catch (Exception e){
                    e.printStackTrace();
                }
                if (connection!=null){
                    connection.disconnect();
                }
            }
        }).start();
    }

    private void showResponse(final String response,final String Filename){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Log.d("debug_con_d",response);
                editor_detail_msg = pref_detail.edit();
                editor_detail_msg.putString(Filename,response);
                editor_detail_msg.apply();
                finish = 1;
            }
        });
    }
}
