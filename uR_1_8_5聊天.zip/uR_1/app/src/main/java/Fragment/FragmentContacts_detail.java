package Fragment;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.PreferenceScreen;
import android.util.Log;

import com.example.ur_1.R;

public class FragmentContacts_detail extends PreferenceFragment {
    private Preference EmailPreference;
    private Preference PhonePreference;
    private Preference SchoolPreference;
    private SharedPreferences pref_detail; //get data from Detail

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.preferences);
        getPreferenceManager().setSharedPreferencesName("mysetting");

        //get data
        pref_detail = getActivity().getSharedPreferences("Detail",0);

        String email = pref_detail.getString("email","");
        EmailPreference = getPreferenceManager().findPreference("Pre_Email");
        EmailPreference.setSummary(email);

        String phone = pref_detail.getString("phone","");
        SchoolPreference = getPreferenceManager().findPreference("Pre_Phone");
        if(phone.equals("\",")){
            Log.d("Phone123","\","+1);
            SchoolPreference.setSummary(" ");
        }else {
            SchoolPreference.setSummary(phone);
        }

        String school = pref_detail.getString("school","");
        SchoolPreference = getPreferenceManager().findPreference("Pre_School");
        SchoolPreference.setSummary(school);
    }

}
