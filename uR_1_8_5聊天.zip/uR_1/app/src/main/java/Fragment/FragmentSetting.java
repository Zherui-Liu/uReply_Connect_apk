package Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.ur_1.Activity.SignIn;
import com.example.ur_1.R;

public class FragmentSetting extends Fragment {
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_setting,container,false);
        //准备logout的button,放置在setting中
        Button logout = (Button)view.findViewById(R.id.setting_logout);
        logout.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getActivity(),SignIn.class);
                startActivity(intent);
//                Toast.makeText(getActivity(),"sth",Toast.LENGTH_SHORT).show();
                //或者我们直接finish这个MyAccount的活动
            }
        });

        return view;
    }
}
