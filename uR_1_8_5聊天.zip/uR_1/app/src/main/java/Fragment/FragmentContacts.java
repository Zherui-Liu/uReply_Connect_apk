package Fragment;

import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.ur_1.R;
import com.example.ur_1.TabFragmentPagerAdapter;

import java.util.ArrayList;
import java.util.List;

public class FragmentContacts extends android.support.v4.app.Fragment implements View.OnClickListener{


    private Button tv_item_one;
    private Button tv_item_two;
    private Button tv_item_three;
    private ViewPager myViewPager;
    private List<android.support.v4.app.Fragment> list;
    private TabFragmentPagerAdapter adapter;
    private View view;
    private Fragment_1 fragment_1;
    private Fragment_2 fragment_2;
    private Fragment_3 fragment_3;

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        view = inflater.inflate(R.layout.contacts_main_fragment,container,false);
        super.onCreate(savedInstanceState);

        InitView();
        tv_item_one.setOnClickListener(this);
        tv_item_two.setOnClickListener(this);
        tv_item_three.setOnClickListener(this);
        myViewPager.setOnPageChangeListener(new MyPagerChangeListener());

//把Fragment添加到List集合里面
        fragment_1 = new Fragment_1();
        fragment_2 = new Fragment_2();
        fragment_3 = new Fragment_3();
        list = new ArrayList<>();
        list.add(fragment_1);
        Log.d("debug-here-fc","1");
        list.add(fragment_2);
        list.add(fragment_3);
        adapter = new TabFragmentPagerAdapter(getChildFragmentManager(), list);
        myViewPager.setAdapter(adapter);
        myViewPager.setCurrentItem(0);  //初始化显示第一个页面

        tv_item_one.setBackgroundResource(R.drawable.orange);

        return view;
    }

    /**
     * 初始化控件
     */
    private void InitView() {
        tv_item_one = (Button) view.findViewById(R.id.tab_students);
        tv_item_two = (Button) view.findViewById(R.id.tab_teachers);
        tv_item_three = (Button) view.findViewById(R.id.tab_adm);
        myViewPager = (ViewPager) view.findViewById(R.id.id_viewpager);
    }

    /**
     * 点击事件
     */
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tab_students:
                myViewPager.setCurrentItem(0);
                    tv_item_one.setBackgroundResource(R.drawable.orange);
                    tv_item_two.setBackgroundResource(R.drawable.orange2);
                    tv_item_three.setBackgroundResource(R.drawable.orange2);
                break;
            case R.id.tab_teachers:
                myViewPager.setCurrentItem(1);
                    tv_item_one.setBackgroundResource(R.drawable.orange2);
                    tv_item_two.setBackgroundResource(R.drawable.orange);
                    tv_item_three.setBackgroundResource(R.drawable.orange2);
                break;
            case R.id.tab_adm:
                myViewPager.setCurrentItem(2);
                    tv_item_one.setBackgroundResource(R.drawable.orange2);
                    tv_item_two.setBackgroundResource(R.drawable.orange2);
                    tv_item_three.setBackgroundResource(R.drawable.orange);
                break;
        }
    }

    /**
     * 设置一个ViewPager的侦听事件，当左右滑动ViewPager时菜单栏被选中状态跟着改变
     *
     */
    public class MyPagerChangeListener implements ViewPager.OnPageChangeListener {

        @Override
        public void onPageScrollStateChanged(int arg0) {
        }

        @Override
        public void onPageScrolled(int arg0, float arg1, int arg2) {
        }

        @Override
        public void onPageSelected(int arg0) {
            switch (arg0) {
                case 0:
                    tv_item_one.setBackgroundResource(R.drawable.orange);
                    tv_item_two.setBackgroundResource(R.drawable.orange2);
                    tv_item_three.setBackgroundResource(R.drawable.orange2);
                    break;
                case 1:
                    tv_item_one.setBackgroundResource(R.drawable.orange2);
                    tv_item_two.setBackgroundResource(R.drawable.orange);
                    tv_item_three.setBackgroundResource(R.drawable.orange2);
                    break;
                case 2:
                    tv_item_one.setBackgroundResource(R.drawable.orange2);
                    tv_item_two.setBackgroundResource(R.drawable.orange2);
                    tv_item_three.setBackgroundResource(R.drawable.orange);
                    break;
            }
        }
    }

}

