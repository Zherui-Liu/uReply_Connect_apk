package Fragment;


import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.renderscript.ScriptIntrinsicYuvToRGB;
import android.support.v4.app.Fragment;
import android.text.Layout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.ur_1.InfoAdapter;
import com.example.ur_1.InfoArticle;
import com.example.ur_1.R;

import java.util.ArrayList;
import java.util.List;

public class FragmentAccount extends Fragment {
    private List<InfoArticle> adapterlist = new ArrayList<>();//这个是用于存储我们每个list的类的名字，虽然我们这里只用到了名字，事实上这代表了一个类，而且这里在创建的时候就已经说明了他们都是InfoArticle的实例。
//    private String[] data = {"a","b"};
    private SharedPreferences pref; //用于读取数据
    private String ma_firstname;
    private String ma_lastname;
    private String ma_email;
    private String ma_tele;
    private String ma_faculty;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.fragment_account,container,false);
//        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1,data);
        pref = getActivity().getSharedPreferences("myaccount", 0);
        ma_firstname = pref.getString("ma_firstname","");
        ma_lastname = pref.getString("ma_lastname","");
        ma_email = pref.getString("ma_email","");
        ma_tele = pref.getString("ma_tele","");
        ma_faculty = pref.getString("ma_faculty","");

        //list
        initArticles();
        InfoAdapter adapter = new InfoAdapter(getActivity(),R.layout.potrait_infor,adapterlist);
        ListView listView = (ListView)view.findViewById(R.id.info_area);//这里指定了具体的将adapter运用到哪个list上面
        listView.setAdapter(adapter);
//获取从login或者从SignIn中传过来的数据


        return view;
    }

    private void initArticles(){ //这个是给listView的方法
        for(int i = 0;i<1;i++){
            InfoArticle name = new InfoArticle("First Name",ma_firstname);
            adapterlist.add(name);
            InfoArticle name1 = new InfoArticle("Last Name",ma_lastname);
            adapterlist.add(name1);
            InfoArticle name2 = new InfoArticle("Email",ma_email);
            adapterlist.add(name2);
            InfoArticle name3 = new InfoArticle("Telephone No.",ma_tele);
            adapterlist.add(name3);
            InfoArticle name4 = new InfoArticle("School/Faculty",ma_faculty);
            adapterlist.add(name4);
        }
    }
}
