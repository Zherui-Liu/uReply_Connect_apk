package Fragment;


import android.app.ActivityOptions;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.example.ur_1.Activity.Contacts_detail;
import com.example.ur_1.ForConAdapter;
import com.example.ur_1.ForContactsItem;
import com.example.ur_1.R;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Fragment_1 extends Fragment {

    //list
    private List<ForContactsItem> adapterlist = new ArrayList<>();
    private int i = 0;
    private SharedPreferences pref_0; //for Load list data
    //pref to transfer data
    private SharedPreferences pref_detail; //for contact detail
    private SharedPreferences.Editor editor_detial;

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.contacts_tab01, null);
        //List
        if(i==0){
            initArticles();
        }

        ForConAdapter adapter = new ForConAdapter(getActivity(),R.layout.contactslistlayout,adapterlist);
        ListView listView = (ListView)view.findViewById(R.id.contactslist_area);//这里指定了具体的将adapter运用到哪个list上面
        listView.setAdapter(adapter);

        //set OnClickListener of ContactList
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ForContactsItem forContactsItem = adapterlist.get(position);
                Toast.makeText(getActivity(),forContactsItem.getFirstname(),Toast.LENGTH_SHORT).show();

                //trans data
                pref_detail = getActivity().getSharedPreferences("Detail",0);
                editor_detial = pref_detail.edit();
                editor_detial.putString("truename",forContactsItem.getTruename()); //actually it should be// username
                editor_detial.putString("firstname",forContactsItem.getFirstname());
                editor_detial.putString("lastname",forContactsItem.getLastname());
                editor_detial.putString("email",forContactsItem.getEmail());
                editor_detial.putString("phone",forContactsItem.getPhone());
                editor_detial.putString("school",forContactsItem.getSchool());
                editor_detial.putString("state",forContactsItem.getState());
                Log.d("debug_123",forContactsItem.getFirstname());
                editor_detial.apply();

                //intent contact detail
                Intent intent = new Intent(getActivity(), Contacts_detail.class);
//                startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(getActivity()).toBundle());
                startActivity(intent);
            }
        });

        return view;
    }

    //initialization of ContactsList
    private void initArticles(){
        //1. receive data locally
        pref_0 = getActivity().getSharedPreferences("Login",0);
        String contactlist = pref_0.getString("ContactList","");
        Log.d("ContactList_1",contactlist);

        //2. clean the data by Regular expression
        Pattern pattern_ = Pattern.compile("susername\":\"(.+?)\",");
        Matcher matcher_ = pattern_.matcher(contactlist);
        Pattern pattern = Pattern.compile("firstname\":\"(.+?)\",");
        Matcher matcher = pattern.matcher(contactlist);
        Pattern pattern0 = Pattern.compile("lastname\":\"(.+?)\",");
        Matcher matcher0 = pattern0.matcher(contactlist);
        Pattern pattern1 = Pattern.compile("\"email\":\"(.+?)\"");
        Matcher matcher1 = pattern1.matcher(contactlist);
        Pattern pattern2 = Pattern.compile("\"tel\":\"(.+?)\"");
        Matcher matcher2 = pattern2.matcher(contactlist);
        Pattern pattern3 = Pattern.compile("\"faculty\":\"(.+?)\"");
        Matcher matcher3 = pattern3.matcher(contactlist);

        //3.add to adapterlist
        while (matcher.find()){

            if (matcher_.find()){Log.d("group_truename",matcher_.group(1));}
            if (matcher0.find()){Log.d("group",matcher0.group(1));}
            if (matcher1.find()){Log.d("group",matcher1.group(1));}
            if (matcher2.find()){Log.d("group",matcher2.group(1));}
            if (matcher3.find()){Log.d("group",matcher3.group(1));}
            //
            ForContactsItem name = new ForContactsItem(matcher_.group(1),matcher.group(1),matcher0.group(1),R.drawable.portrait,matcher1.group(1),matcher2.group(1),matcher3.group(1),"student");
            adapterlist.add(name);
            }

        i=1;
    }
}

