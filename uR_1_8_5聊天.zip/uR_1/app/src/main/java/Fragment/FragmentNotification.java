package Fragment;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.ur_1.R;

public class FragmentNotification extends Fragment {
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceStated){
        View view = inflater.inflate(R.layout.fragment_notification,container,false);
        return view;
    }
}
