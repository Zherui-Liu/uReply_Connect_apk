package com.example.ur_0;

/**
 * Created by Administrator on 2018/7/17.
 */

public class InfoArticle {
    private String name;

    public InfoArticle(String name){
        this.name = name;
    }

    public String getName(){
        return name;
    }
}
